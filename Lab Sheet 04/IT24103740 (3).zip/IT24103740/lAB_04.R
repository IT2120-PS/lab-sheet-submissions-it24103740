setwd("C://Users//it24103740//Desktop//IT24103740")

branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")
str(branch_data)
fix(branch_data)
boxplot(X1,main="Box plot for Sales",outline=TRUE,outpch=8,horizontal=TRUE)
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)
check_Outliers<-function(x){
  Q1<-quantile(x,0.25)
  Q2<-quantile(x, 0.7)
  IQR<-Q2-Q1
  lower <- Q1 - 1.5 * IQR
  upper <- Q2 - 1.5 * IQR
  return(x[x < lower | x > upper])
}
check_Outliers(branch_data$Years_X3)
